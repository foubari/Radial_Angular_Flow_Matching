from setuptools import setup, find_packages

setup(
    name="rafm",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "torch>=2.0.0",
        "numpy>=1.24.0",
        "scipy>=1.10.0",
        "scikit-learn>=1.2.0",
        "matplotlib>=3.7.0",
        "seaborn>=0.12.0",
        "pandas>=2.0.0",
        "pyyaml>=6.0",
        "pot>=0.9.0",
        "tqdm>=4.65.0",
    ],
    python_requires=">=3.9",
)
