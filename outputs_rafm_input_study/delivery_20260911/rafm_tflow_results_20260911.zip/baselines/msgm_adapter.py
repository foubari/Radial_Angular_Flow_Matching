"""MSGM adapter — wraps 18727.../SDEs.py for our evaluation interface.

Never modifies the original MSGM code.
Provides train(), sample(), time_training(), time_sampling() methods
that conform to the same interface as our FM methods.
"""
import sys
import time
from pathlib import Path

import torch

# Add MSGM reference code to path (without modifying it)
MSGM_DIR = Path(__file__).parent.parent / "18727_Multiplicative_Diffusion_code"
if str(MSGM_DIR) not in sys.path:
    sys.path.insert(0, str(MSGM_DIR))


class MSGMAdapter:
    """Adapter for the Multiplicative Diffusion baseline.

    Uses the same training data, architecture parameters, and random seeds
    as our FM baselines to ensure fair comparison.
    """

    def __init__(self, train_data: torch.Tensor, cfg: dict, device: str = "cpu"):
        self.train_data = train_data
        self.cfg = cfg
        self.device = device
        self.dim = train_data.shape[1]
        self._sde = None
        self._model = None

    def build(self) -> None:
        """Initialize MSGM model from MSGM reference code."""
        from SDEs import multiplicativeNoise
        from NN import MLP

        # Use eCDF estimator by default (matches our default choice)
        self._sde = multiplicativeNoise(
            y0=self.train_data.to(self.device),
            norm_sampler="ecdf",
            device=self.device,
        )
        # Fix: MSGM's sde_scheme.py expects T to be a tensor (sde.T.device),
        # but multiplicativeNoise stores it as a plain float.
        self._sde.T = torch.tensor(self._sde.T, device=self.device)

        self._model = MLP(
            input_dim=self.dim,
            hidden_dim=self.cfg.get("hidden_dim", 128),
        ).to(self.device)

    def train(self, seed: int = 0, ckpt_dir: Path | None = None) -> dict:
        """Train MSGM with sliced score matching. Resumes from checkpoint if available."""
        if self._sde is None:
            self.build()

        from torch.optim import Adam
        import random, numpy as np

        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

        optimizer = Adam(self._model.parameters(), lr=self.cfg.get("lr", 1e-3))
        n_steps = self.cfg.get("n_train_steps", 10_000)
        batch_size = self.cfg.get("batch_size", 256)
        ckpt_every = self.cfg.get("ckpt_every", 1000)

        # Import SSM loss from MSGM
        from SDEs import PluginReverseSDE

        self._gen_sde = PluginReverseSDE(self._sde, self._model, T=self._sde.T,
                                         debias=False).to(self.device)

        # Resume from checkpoint if available
        start_step = 0
        elapsed_before = 0.0
        ckpt_path = Path(ckpt_dir) / "msgm_ckpt.pt" if ckpt_dir else None
        if ckpt_path and ckpt_path.exists():
            ckpt = torch.load(ckpt_path, weights_only=False)
            self._model.load_state_dict(ckpt["model"])
            optimizer.load_state_dict(ckpt["optimizer"])
            start_step = ckpt["step"]
            elapsed_before = ckpt.get("elapsed_s", 0.0)
            print(f"  Resuming from checkpoint at step {start_step}")

        # Pre-load train data on GPU
        train_gpu = self.train_data.to(self.device)
        n_train = train_gpu.shape[0]

        from tqdm import tqdm
        # Train log CSV
        log_path = (ckpt_dir / "train_log.csv") if ckpt_dir else None
        log_rows = []
        if log_path and log_path.exists():
            import csv
            with open(log_path) as f:
                log_rows = list(csv.DictReader(f))

        t0 = time.time()
        pbar = tqdm(range(start_step + 1, n_steps + 1), desc="msgm",
                     dynamic_ncols=True, initial=start_step, total=n_steps)
        for step in pbar:
            idx = torch.randint(n_train, (batch_size,), device=self.device)
            x = train_gpu[idx]
            optimizer.zero_grad(set_to_none=True)
            loss = self._gen_sde.ssm(x).mean()
            loss.backward()
            optimizer.step()
            if step % 500 == 0:
                pbar.set_postfix(loss=f"{loss.item():.4f}")
                if log_path:
                    log_rows.append({
                        "step": step,
                        "loss": loss.item(),
                        "elapsed_s": elapsed_before + (time.time() - t0),
                    })
                    import csv
                    with open(log_path, "w", newline="") as f:
                        w = csv.DictWriter(f, fieldnames=["step", "loss", "elapsed_s"])
                        w.writeheader()
                        w.writerows(log_rows)
            if ckpt_path and step % ckpt_every == 0:
                torch.save({
                    "step": step,
                    "model": self._model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "elapsed_s": elapsed_before + (time.time() - t0),
                }, ckpt_path)

        total_time = elapsed_before + (time.time() - t0)
        # Clean up checkpoint after successful completion
        if ckpt_path and ckpt_path.exists():
            ckpt_path.unlink()
        return {"total_train_time_s": total_time}

    @torch.no_grad()
    def sample(self, n: int) -> dict:
        """Generate n samples using MSGM reverse process."""
        from sde_scheme import rk4_stratonovich_sampler
        if self._sde is None:
            self.build()

        x0 = self._sde.latent_sample(n, self.dim)
        t0 = time.time()
        xs = rk4_stratonovich_sampler(
            self._gen_sde, x0, num_steps=self.cfg.get("nfe", 128),
            keep_all_samples=False
        )
        return {"samples": xs.cpu(), "sample_time_s": time.time() - t0}

    def time_training(self, n_steps: int = 1000) -> dict:
        """Measure per-step training time."""
        if self._sde is None:
            self.build()
        from torch.optim import Adam
        optimizer = Adam(self._model.parameters())
        batch_size = self.cfg.get("batch_size", 256)

        # Warmup
        for _ in range(10):
            idx = torch.randint(len(self.train_data), (batch_size,))
            x = self.train_data[idx].to(self.device)
            # Simple forward pass timing (full SSM would need PluginReverseSDE)
            _ = self._model(x, torch.ones(batch_size, 1, device=self.device) * 0.5)

        t0 = time.time()
        for _ in range(n_steps):
            idx = torch.randint(len(self.train_data), (batch_size,))
            x = self.train_data[idx].to(self.device)
            t_rand = torch.rand(batch_size, 1, device=self.device)
            _ = self._model(x, t_rand)

        elapsed = time.time() - t0
        return {"time_per_step_ms": elapsed / n_steps * 1000, "peak_memory_mb": 0.0}

    def time_sampling(self, n: int, nfe_list: list[int]) -> dict:
        """Measure sampling time at various NFE."""
        if self._sde is None:
            self.build()
        results = {}
        for nfe in nfe_list:
            x0 = self._sde.latent_sample(n, self.dim)
            t0 = time.time()
            from sde_scheme import rk4_stratonovich_sampler
            # Note: forward_SDE wrapper needed for proper sampling
            rk4_stratonovich_sampler(
                self._sde, x0, num_steps=nfe, keep_all_samples=False
            )
            results[f"sample_time_nfe{nfe}_s"] = time.time() - t0
        return results
